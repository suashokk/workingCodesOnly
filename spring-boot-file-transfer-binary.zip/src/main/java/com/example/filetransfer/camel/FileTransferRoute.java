package com.example.filetransfer.camel;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class FileTransferRoute extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:fileTransfer")
            .log("Processing binary file transfer for: ${header.fileName}")
            .toD("file:${header.destinationPath}?fileName=${header.fileName}")
            .log("Binary file transferred successfully to ${header.destinationPath}/${header.fileName}");
    }
}
