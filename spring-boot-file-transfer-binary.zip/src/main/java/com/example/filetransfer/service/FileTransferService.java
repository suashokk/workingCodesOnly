package com.example.filetransfer.service;

import org.apache.camel.ProducerTemplate;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Service
public class FileTransferService {
    private final ProducerTemplate producerTemplate;

    public FileTransferService(ProducerTemplate producerTemplate) {
        this.producerTemplate = producerTemplate;
    }

    public String transferBinaryFile(byte[] fileData, String fileName, String destinationPath) throws IOException {
        if (fileData.length == 0) {
            return "File is empty. Upload failed.";
        }

        // Create destination file
        File destFile = new File(destinationPath + "/" + fileName);

        // Write binary data to file
        try (FileOutputStream fos = new FileOutputStream(destFile)) {
            fos.write(fileData);
        }

        // Process file with Apache Camel
        producerTemplate.sendBodyAndHeader("direct:fileTransfer", destFile, "fileName", fileName);

        return "File uploaded successfully to " + destinationPath;
    }
}
