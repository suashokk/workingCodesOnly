package com.example.filetransfer.controller;

import com.example.filetransfer.service.FileTransferService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/api/files")
public class FileTransferController {
    private final FileTransferService fileTransferService;

    public FileTransferController(FileTransferService fileTransferService) {
        this.fileTransferService = fileTransferService;
    }

    // Accept binary files in the request body
    @PostMapping(value = "/upload", consumes = "application/octet-stream")
    public ResponseEntity<String> uploadBinaryFile(
            @RequestBody byte[] fileData,
            @RequestHeader("fileName") String fileName,
            @RequestHeader("destinationPath") String destinationPath) {
        try {
            String response = fileTransferService.transferBinaryFile(fileData, fileName, destinationPath);
            return ResponseEntity.ok(response);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("File upload failed: " + e.getMessage());
        }
    }
}
