package com.example.filetransfer.service;

import com.example.filetransfer.dto.FileTransferRequest;
import org.apache.camel.ProducerTemplate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FileTransferServiceTest {
    private ProducerTemplate producerTemplate;
    private FileTransferService fileTransferService;

    @BeforeEach
    void setUp() {
        producerTemplate = mock(ProducerTemplate.class);
        fileTransferService = new FileTransferService(producerTemplate);
    }

    @Test
    void testTransferFile_Success() {
        FileTransferRequest request = new FileTransferRequest("/home/source", "/home/destination", "test.txt");

        doNothing().when(producerTemplate).sendBodyAndHeaders(anyString(), isNull(), anyMap());

        String response = fileTransferService.transferFile(request);

        assertEquals("File transfer initiated successfully.", response);
        verify(producerTemplate, times(1)).sendBodyAndHeaders(anyString(), isNull(), anyMap());
    }
}
