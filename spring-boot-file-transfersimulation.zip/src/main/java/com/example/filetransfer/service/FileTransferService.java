package com.example.filetransfer.service;

import com.example.filetransfer.dto.FileTransferRequest;
import org.apache.camel.ProducerTemplate;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class FileTransferService {
    private final ProducerTemplate producerTemplate;

    public FileTransferService(ProducerTemplate producerTemplate) {
        this.producerTemplate = producerTemplate;
    }

    public String transferFile(FileTransferRequest request) {
        try {
            producerTemplate.sendBodyAndHeaders("direct:fileTransfer", null, Map.of(
                "sourceFilePath", request.getSourceFilePath(),
                "destinationFilePath", request.getDestinationFilePath(),
                "fileName", request.getFileName()
            ));
            return "File transfer initiated successfully.";
        } catch (Exception e) {
            return "File transfer failed: " + e.getMessage();
        }
    }
}
