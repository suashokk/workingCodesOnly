package com.example.filetransfer.camel;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class FileTransferRoute extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:fileTransfer")
            .log("Processing file transfer: ${body}")
            .toD("file:${header.destinationFilePath}?fileName=${header.fileName}")
            .log("File transferred successfully to ${header.destinationFilePath}/${header.fileName}");
    }
}
