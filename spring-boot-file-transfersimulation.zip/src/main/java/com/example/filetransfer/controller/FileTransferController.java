package com.example.filetransfer.controller;

import com.example.filetransfer.dto.FileTransferRequest;
import com.example.filetransfer.service.FileTransferService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/files")
public class FileTransferController {
    private final FileTransferService fileTransferService;

    public FileTransferController(FileTransferService fileTransferService) {
        this.fileTransferService = fileTransferService;
    }

    @PostMapping("/transfer")
    public ResponseEntity<String> transferFile(@RequestBody FileTransferRequest request) {
        String response = fileTransferService.transferFile(request);
        return ResponseEntity.ok(response);
    }
}
