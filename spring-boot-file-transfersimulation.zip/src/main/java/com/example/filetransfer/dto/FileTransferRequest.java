package com.example.filetransfer.dto;

public class FileTransferRequest {
    private String sourceFilePath;
    private String destinationFilePath;
    private String fileName;

    public FileTransferRequest() {}

    public FileTransferRequest(String sourceFilePath, String destinationFilePath, String fileName) {
        this.sourceFilePath = sourceFilePath;
        this.destinationFilePath = destinationFilePath;
        this.fileName = fileName;
    }

    public String getSourceFilePath() { return sourceFilePath; }
    public void setSourceFilePath(String sourceFilePath) { this.sourceFilePath = sourceFilePath; }

    public String getDestinationFilePath() { return destinationFilePath; }
    public void setDestinationFilePath(String destinationFilePath) { this.destinationFilePath = destinationFilePath; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
}
