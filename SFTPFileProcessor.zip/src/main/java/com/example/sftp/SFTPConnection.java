package com.example.sftp;

import com.jcraft.jsch.*;

public class SFTPConnection {
    private static Session session;
    private static ChannelSftp channelSftp;

    public static void connect(String username, String host, int port, String password) throws JSchException {
        if (session == null || !session.isConnected()) {
            JSch jsch = new JSch();
            session = jsch.getSession(username, host, port);
            session.setPassword(password);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setServerAliveInterval(60000);
            session.connect();
        }
        if (channelSftp == null || !channelSftp.isConnected()) {
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
        }
    }

    public static ChannelSftp getChannel() {
        return channelSftp;
    }

    public static void disconnect() {
        if (channelSftp != null) {
            channelSftp.disconnect();
        }
        if (session != null) {
            session.disconnect();
        }
    }
}
