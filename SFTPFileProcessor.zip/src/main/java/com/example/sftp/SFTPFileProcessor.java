package com.example.sftp;

import com.jcraft.jsch.*;
import java.io.*;
import java.util.concurrent.*;

public class SFTPFileProcessor {
    private static final String SFTP_HOST = "sftp.example.com";
    private static final int SFTP_PORT = 22;
    private static final String SFTP_USER = "yourUsername";
    private static final String SFTP_PASS = "yourPassword";
    private static final String SOURCE_DIR = "/local/source/";
    private static final String DEST_DIR = "/remote/destination/";
    private static final int THREADS = 5;
    private static final int MAX_RETRIES = 3;

    public static void main(String[] args) throws InterruptedException {
        File folder = new File(SOURCE_DIR);
        File[] files = folder.listFiles();
        if (files == null || files.length == 0) {
            System.out.println("No files found in the source directory.");
            return;
        }

        try {
            SFTPConnection.connect(SFTP_USER, SFTP_HOST, SFTP_PORT, SFTP_PASS);
        } catch (JSchException e) {
            System.err.println("SFTP Connection Failed: " + e.getMessage());
            return;
        }

        ExecutorService executor = Executors.newFixedThreadPool(THREADS);
        for (File file : files) {
            executor.execute(() -> uploadFile(file.getAbsolutePath()));
        }

        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.HOURS);

        SFTPConnection.disconnect();
        System.out.println("All files processed successfully.");
    }

    public static void uploadFile(String filePath) {
        String fileName = new File(filePath).getName();
        String remoteFilePath = DEST_DIR + fileName;

        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                ChannelSftp sftp = SFTPConnection.getChannel();
                sftp.put(filePath, remoteFilePath);
                System.out.println("Uploaded: " + fileName);
                return;
            } catch (SftpException e) {
                System.err.println("Attempt " + attempt + " failed for " + fileName + ": " + e.getMessage());
                if (attempt == MAX_RETRIES) {
                    System.err.println("Giving up on " + fileName);
                }
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}
