package com.example.hcp.controller;

import com.example.hcp.service.HcpService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/hcp")
@RequiredArgsConstructor
public class HcpController {

    private final HcpService hcpService;

    @GetMapping("/docs")
    public ResponseEntity<String> getDocs() {
        String response = hcpService.fetchHcpDocs();
        return ResponseEntity.ok(response);
    }
}
