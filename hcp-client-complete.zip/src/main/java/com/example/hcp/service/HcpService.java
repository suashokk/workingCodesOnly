package com.example.hcp.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.example.hcp.exception.HcpClientException;

@Service
@RequiredArgsConstructor
public class HcpService {

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${hcp.api.url}")
    private String hcpApiUrl;

    public String fetchHcpDocs() {
        if (hcpApiUrl == null || hcpApiUrl.isBlank()) {
            throw new HcpClientException("HCP API URL is not configured.");
        }

        try {
            ResponseEntity<String> response = restTemplate.getForEntity(hcpApiUrl, String.class);
            return response.getBody();
        } catch (Exception ex) {
            throw new HcpClientException("Failed to call HCP API: " + ex.getMessage(), ex);
        }
    }
}
