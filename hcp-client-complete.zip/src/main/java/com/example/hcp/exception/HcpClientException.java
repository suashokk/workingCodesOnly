package com.example.hcp.exception;

public class HcpClientException extends RuntimeException {
    public HcpClientException(String message) {
        super(message);
    }

    public HcpClientException(String message, Throwable cause) {
        super(message, cause);
    }
}
