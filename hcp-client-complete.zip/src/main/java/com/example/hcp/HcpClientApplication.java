package com.example.hcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HcpClientApplication {
    public static void main(String[] args) {
        SpringApplication.run(HcpClientApplication.class, args);
    }
}
