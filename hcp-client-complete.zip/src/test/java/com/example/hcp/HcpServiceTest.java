package com.example.hcp.service;

import com.example.hcp.exception.HcpClientException;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class HcpServiceTest {

    @InjectMocks
    private HcpService hcpService;

    @Test
    void fetchHcpDocs_withValidUrl_returnsResponse() {
        ReflectionTestUtils.setField(hcpService, "hcpApiUrl", "https://httpbin.org/get");
        assertNotNull(hcpService.fetchHcpDocs());
    }

    @Test
    void fetchHcpDocs_withInvalidUrl_throwsException() {
        ReflectionTestUtils.setField(hcpService, "hcpApiUrl", "https://invalid.url");
        assertThrows(HcpClientException.class, () -> hcpService.fetchHcpDocs());
    }

    @Test
    void fetchHcpDocs_withBlankUrl_throwsException() {
        ReflectionTestUtils.setField(hcpService, "hcpApiUrl", "");
        assertThrows(HcpClientException.class, () -> hcpService.fetchHcpDocs());
    }
}
