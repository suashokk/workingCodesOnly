package com.example.hcp.controller;

import com.example.hcp.service.HcpService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(HcpController.class)
public class HcpControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private HcpService hcpService;

    @InjectMocks
    private HcpController hcpController;

    @Test
    void getDocs_returnsOk() throws Exception {
        when(hcpService.fetchHcpDocs()).thenReturn("Test Response");

        mockMvc.perform(get("/api/hcp/docs"))
               .andExpect(status().isOk());
    }
}
