package com.example.sftp.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SftpConfig {
    // Configure SFTP connection details
}