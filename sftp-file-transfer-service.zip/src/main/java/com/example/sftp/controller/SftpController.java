package com.example.sftp.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.example.sftp.service.SftpService;

@RestController
@RequestMapping("/sftp")
public class SftpController {
    private final SftpService sftpService;

    public SftpController(SftpService sftpService) {
        this.sftpService = sftpService;
    }

    @PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file) {
        return sftpService.uploadFile(file);
    }
}