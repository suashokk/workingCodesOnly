package com.example.sftp.service;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.web.multipart.MultipartFile;

@ExtendWith(MockitoExtension.class)
class SftpServiceTest {
    @InjectMocks
    private SftpService sftpService;

    @Mock
    private MultipartFile file;

    @Test
    void shouldUploadFileSuccessfully() {
        when(file.getOriginalFilename()).thenReturn("test.txt");
        String result = sftpService.uploadFile(file);
        assertEquals("File uploaded successfully", result);
    }
}