package com.example.sftp.controller;

import com.example.sftp.service.SftpService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Vector;

@RestController
@RequestMapping("/sftp")
public class SftpController {

    private final SftpService sftpService;

    public SftpController(SftpService sftpService) {
        this.sftpService = sftpService;
    }

    @PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            String tempFile = System.getProperty("java.io.tmpdir") + file.getOriginalFilename();
            file.transferTo(new java.io.File(tempFile));
            sftpService.uploadFile(tempFile);
            return "File uploaded successfully";
        } catch (Exception e) {
            return "Error uploading file: " + e.getMessage();
        }
    }

    @GetMapping("/list")
    public Vector<?> listFiles() {
        try {
            return sftpService.listFiles();
        } catch (Exception e) {
            return null;
        }
    }

    @DeleteMapping("/delete/{fileName}")
    public String deleteFile(@PathVariable String fileName) {
        try {
            sftpService.deleteFile(fileName);
            return "File deleted successfully";
        } catch (Exception e) {
            return "Error deleting file: " + e.getMessage();
        }
    }
}
