package com.example.sftp.service;

import com.jcraft.jsch.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Vector;

@Service
public class SftpService {

    @Value("${sftp.host}")
    private String host;

    @Value("${sftp.port}")
    private int port;

    @Value("${sftp.username}")
    private String username;

    @Value("${sftp.password}")
    private String password;

    @Value("${sftp.remote-directory}")
    private String remoteDir;

    private ChannelSftp setupJsch() throws JSchException {
        JSch jsch = new JSch();
        Session session = jsch.getSession(username, host, port);
        session.setPassword(password);
        session.setConfig("StrictHostKeyChecking", "no");
        session.connect();
        
        Channel channel = session.openChannel("sftp");
        channel.connect();
        return (ChannelSftp) channel;
    }

    public void uploadFile(String localFilePath) throws Exception {
        ChannelSftp channelSftp = setupJsch();
        channelSftp.put(new FileInputStream(new File(localFilePath)), remoteDir + new File(localFilePath).getName());
        channelSftp.disconnect();
    }

    public void downloadFile(String remoteFileName, String localPath) throws Exception {
        ChannelSftp channelSftp = setupJsch();
        FileOutputStream fileOutputStream = new FileOutputStream(new File(localPath + remoteFileName));
        channelSftp.get(remoteDir + remoteFileName, fileOutputStream);
        fileOutputStream.close();
        channelSftp.disconnect();
    }

    public Vector<?> listFiles() throws Exception {
        ChannelSftp channelSftp = setupJsch();
        Vector<?> files = channelSftp.ls(remoteDir);
        channelSftp.disconnect();
        return files;
    }

    public void deleteFile(String remoteFileName) throws Exception {
        ChannelSftp channelSftp = setupJsch();
        channelSftp.rm(remoteDir + remoteFileName);
        channelSftp.disconnect();
    }
}
