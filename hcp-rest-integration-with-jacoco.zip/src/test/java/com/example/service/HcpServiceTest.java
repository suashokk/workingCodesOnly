package com.example.service;

import com.example.util.HcpRestClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class HcpServiceTest {

    @Mock
    private HcpRestClient hcpRestClient;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private HcpService hcpService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        hcpService = new HcpService(hcpRestClient);
        hcpService.hcpToken = "dummy-token"; // simulate @Value injection
    }

    @Test
    void testDownloadFileWithToken_Success() throws IOException {
        String dummyUrl = "http://dummy.com/file";
        String savePath = "/mnt/data/temp_test_file.txt";
        byte[] fileContent = "Test content".getBytes();

        when(restTemplate.exchange(eq(dummyUrl), eq(HttpMethod.GET),
                any(), eq(byte[].class)))
                .thenReturn(new ResponseEntity<>(fileContent, HttpStatus.OK));

        // Inject the mock RestTemplate
        hcpService.restTemplate = restTemplate;

        String result = hcpService.downloadFileWithToken(dummyUrl, savePath);
        assertTrue(result.contains("Download successful"));

        File savedFile = new File(savePath);
        assertTrue(savedFile.exists());

        // Cleanup
        savedFile.delete();
    }

    @Test
    void testDownloadFileWithToken_Failure() {
        String dummyUrl = "http://dummy.com/file";
        String savePath = "/mnt/data/failure_test_file.txt";

        when(restTemplate.exchange(eq(dummyUrl), eq(HttpMethod.GET),
                any(), eq(byte[].class)))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR));

        hcpService.restTemplate = restTemplate;

        String result = hcpService.downloadFileWithToken(dummyUrl, savePath);
        assertTrue(result.contains("Download failed"));
    }
}