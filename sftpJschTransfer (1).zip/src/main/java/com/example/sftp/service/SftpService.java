package com.example.sftp.service;

import com.jcraft.jsch.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class SftpService {

    @Value("${sftp.host}")
    private String sftpHost;

    @Value("${sftp.port}")
    private int sftpPort;

    @Value("${sftp.username}")
    private String sftpUsername;

    @Value("${sftp.password}")
    private String sftpPassword;

    /**
     * Move a file from one location to another on the same SFTP server.
     */
    public String moveFile(String sourceFilePath, String destinationFilePath) {
        Session session = null;
        ChannelSftp channelSftp = null;

        try {
            // Create SSH session
            JSch jsch = new JSch();
            session = jsch.getSession(sftpUsername, sftpHost, sftpPort);
            session.setPassword(sftpPassword);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();

            // Open SFTP channel
            Channel channel = session.openChannel("sftp");
            channel.connect();
            channelSftp = (ChannelSftp) channel;

            // Move file within the remote server
            channelSftp.rename(sourceFilePath, destinationFilePath);

            return "File moved successfully from " + sourceFilePath + " to " + destinationFilePath;

        } catch (Exception e) {
            return "Error moving file: " + e.getMessage();
        } finally {
            if (channelSftp != null) channelSftp.disconnect();
            if (session != null) session.disconnect();
        }
    }
}
