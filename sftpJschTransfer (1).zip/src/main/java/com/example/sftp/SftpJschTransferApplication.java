package com.example.sftp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SftpJschTransferApplication {
    public static void main(String[] args) {
        SpringApplication.run(SftpJschTransferApplication.class, args);
    }
}
