package com.example.filetransfer.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

@RestController
@RequestMapping("/file")
@Slf4j
public class FileTransferController {

    private final String TARGET_DIRECTORY = "C:\\UploadedFiles\\";

    @PostMapping("/send")
    public ResponseEntity<String> sendFile(@RequestParam("file") MultipartFile file) {
        File tempFile = null;
        try {
            tempFile = convertMultipartFileToFile(file);

            // Save file locally instead of sending over network
            boolean isSaved = saveFileToLocalDirectory(tempFile);

            // Delete temporary file
            tempFile.delete();

            return isSaved ? ResponseEntity.ok("File saved successfully at " + TARGET_DIRECTORY) :
                    ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("File saving failed!");
        } catch (IOException e) {
            System.out.println("File processing error: ");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("File processing error!");
        }
    }

    private boolean saveFileToLocalDirectory(File file) {
        try {
            File targetDir = new File(TARGET_DIRECTORY);

            // Create directory if it does not exist
            if (!targetDir.exists()) {
                targetDir.mkdirs();
            }

            // Define target file path
            File targetFile = new File(TARGET_DIRECTORY + file.getName());

            // Copy file to target directory
            Files.copy(file.toPath(), targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

            System.out.println("File saved successfully: " + targetFile.getAbsolutePath());
            return true;
        } catch (IOException e) {
            System.out.println("Error saving file to local directory: ");
            return false;
        }
    }

    private File convertMultipartFileToFile(MultipartFile multipartFile) throws IOException {
        File convFile = File.createTempFile("upload-", "-" + multipartFile.getOriginalFilename());
        try (FileOutputStream fos = new FileOutputStream(convFile)) {
            fos.write(multipartFile.getBytes());
        }
        return convFile;
    }
}
