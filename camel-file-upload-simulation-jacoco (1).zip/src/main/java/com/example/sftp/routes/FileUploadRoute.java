package com.example.sftp.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class FileUploadRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        from("direct:fileUpload")
            .routeId("fileUploadRoute")
            .log("Received file: ${header.CamelFileName}")
            .to("file://target/uploaded-files"); // Saves file to local folder
    }
}