package com.example.sftp.controller;

import org.apache.camel.ProducerTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/files")
public class FileUploadController {

    private final ProducerTemplate producerTemplate;

    public FileUploadController(ProducerTemplate producerTemplate) {
        this.producerTemplate = producerTemplate;
    }

    @PostMapping("/upload")
    public ResponseEntity<Map<String, String>> uploadFile(@RequestParam("file") MultipartFile file) {
        Map<String, Object> headers = new HashMap<>();
        headers.put("CamelHttpMethod", "POST");
        headers.put("CamelFileName", file.getOriginalFilename());

        // Send file to Camel route
        producerTemplate.sendBodyAndHeaders("direct:fileUpload", file.getBytes(), headers);

        Map<String, String> response = new HashMap<>();
        response.put("message", "File uploaded successfully");
        response.put("fileName", file.getOriginalFilename());

        return ResponseEntity.ok(response);
    }
}