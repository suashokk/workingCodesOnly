
@RestController
@RequestMapping("/batch")
public class BatchController {
    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job dataProcessingJob;

    @PostMapping("/run")
    public ResponseEntity<String> runBatch() throws Exception {
        JobParameters parameters = new JobParametersBuilder()
                .addLong("time", System.currentTimeMillis())
                .toJobParameters();
        jobLauncher.run(dataProcessingJob, parameters);
        return ResponseEntity.ok("Batch job initiated");
    }
}
    