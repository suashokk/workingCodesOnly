
@Component
public class PersonItemReader implements ItemReader<Person> {
    private final List<Person> data = List.of(new Person("John", "Doe"), new Person("Jane", "Smith"));
    private int index = 0;

    @Override
    public Person read() {
        if (index < data.size()) {
            return data.get(index++);
        } else {
            return null;
        }
    }
}
    