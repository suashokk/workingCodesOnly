
@SpringBootApplication
public class SpringBatchMicroserviceApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringBatchMicroserviceApplication.class, args);
    }
}
    