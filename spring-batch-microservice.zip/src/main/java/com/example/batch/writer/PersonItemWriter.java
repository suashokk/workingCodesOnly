
@Component
public class PersonItemWriter implements ItemWriter<Person> {
    @Override
    public void write(List<? extends Person> items) {
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
    