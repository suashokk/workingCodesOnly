
@Configuration
@EnableBatchProcessing
public class BatchConfig {
    @Bean
    public Job dataProcessingJob(JobBuilderFactory jobBuilderFactory, Step dataProcessingStep) {
        return jobBuilderFactory.get("dataProcessingJob")
                .incrementer(new RunIdIncrementer())
                .flow(dataProcessingStep)
                .end()
                .build();
    }

    @Bean
    public Step dataProcessingStep(StepBuilderFactory stepBuilderFactory, ItemReader<Person> reader,
                                   ItemProcessor<Person, Person> processor, ItemWriter<Person> writer) {
        return stepBuilderFactory.get("dataProcessingStep")
                .<Person, Person>chunk(10)
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .build();
    }
}
    