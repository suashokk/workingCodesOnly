package com.example.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HcpServiceTest {

    private final HcpService service = new HcpService();

    @Test
    void shouldReturnUploadedPath() {
        String result = service.uploadToHcp("test.txt", "hello".getBytes(), "text/plain");
        assertEquals("uploaded-path/test.txt", result);
    }

    @Test
    void shouldThrowForInvalidInput() {
        assertThrows(IllegalArgumentException.class, () -> service.uploadToHcp(null, null, null));
    }
}
