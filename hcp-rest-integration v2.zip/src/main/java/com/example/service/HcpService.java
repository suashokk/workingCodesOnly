package com.example.service;

import org.springframework.stereotype.Service;

@Service
public class HcpService {
    public String uploadToHcp(String fileName, byte[] fileBytes, String contentType) {
        if (fileName == null || fileBytes == null || fileBytes.length == 0) {
            throw new IllegalArgumentException("Invalid input");
        }
        return "uploaded-path/" + fileName;
    }
}
