package com.example.controller;

import com.example.service.HcpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/hcp")
public class HcpController {

    @Autowired
    private HcpService hcpService;

    @PostMapping("/upload")
    public ResponseEntity<String> upload(@RequestParam("file") MultipartFile file) throws Exception {
        String result = hcpService.uploadToHcp(file.getOriginalFilename(), file.getBytes(), file.getContentType());
        return ResponseEntity.ok(result);
    }
}
