package com.example.sftp.controller;

import com.example.sftp.service.SftpService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/sftp")
public class SftpController {

    private final SftpService sftpService;

    public SftpController(SftpService sftpService) {
        this.sftpService = sftpService;
    }

    /**
     * Move a file from one location to another on the same SFTP server
     */
    @PostMapping("/move")
    public ResponseEntity<String> moveFile(@RequestParam String sourceFile, @RequestParam String destinationFile) {
        String response = sftpService.moveFile(sourceFile, destinationFile);
        return ResponseEntity.ok(response);
    }
}
